// GameModelJUnitTest.java
// Professional JUnit test file

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class GameModelJUnitTest {
    private GameModel game;
    
    @Before
    public void setUp() {
        game = new GameModel();
    }
    
    @Test
    public void testInitialState() {
        assertFalse("Game should not be running initially", game.isGameRunning());
        assertFalse("Game should not be paused initially", game.isGamePaused());
        assertEquals("Initial score should be 0", 0, game.getScore());
        assertEquals("Initial lives should be 3", 3, game.getLives());
        assertEquals("Initial level should be 1", 1, game.getLevel());
    }
    
    @Test
    public void testStartGame() {
        game.startGame();
        
        assertTrue("Game should be running after start", game.isGameRunning());
        assertEquals("Score should reset to 0", 0, game.getScore());
        assertEquals("Lives should be 3", 3, game.getLives());
        assertEquals("Level should be 1", 1, game.getLevel());
    }
    
    @Test
    public void testThemeCycle() {
        int initialTheme = game.getCurrentTheme();
        
        // Test one theme change
        game.changeTheme();
        assertEquals("Theme should increment by 1", 
                    (initialTheme + 1) % 4, game.getCurrentTheme());
        
        // Test full cycle (4 changes should return to start)
        for (int i = 0; i < 3; i++) {
            game.changeTheme();
        }
        assertEquals("After 4 theme changes, should return to original",
                    initialTheme, game.getCurrentTheme());
    }
    
    @Test
    public void testPaddleMovementWithinBounds() {
        game.startGame();
        double initialX = game.getPaddleX();
        
        // Move right
        game.movePaddle(50);
        assertTrue("Paddle should move right", game.getPaddleX() > initialX);
        
        // Move left
        initialX = game.getPaddleX();
        game.movePaddle(-50);
        assertTrue("Paddle should move left", game.getPaddleX() < initialX);
    }
    
    @Test
    public void testPauseToggle() {
        game.startGame();
        
        // First toggle - should pause
        game.togglePause();
        assertTrue("Game should be paused", game.isGamePaused());
        
        // Second toggle - should resume
        game.togglePause();
        assertFalse("Game should be resumed", game.isGamePaused());
    }
    
    @Test
    public void testBallMovementOnUpdate() {
        game.startGame();
        
        double initialX = game.getBallX();
        double initialY = game.getBallY();
        
        game.update();
        
        assertNotEquals("Ball X should change after update", 
                       initialX, game.getBallX(), 0.001);
        assertNotEquals("Ball Y should change after update", 
                       initialY, game.getBallY(), 0.001);
    }
    
    @Test
    public void testGameConstants() {
        assertEquals("Game width should be 800", 800, GameModel.WIDTH);
        assertEquals("Game height should be 600", 600, GameModel.HEIGHT);
        assertEquals("Paddle width should be 120", 120, GameModel.PADDLE_WIDTH);
        assertEquals("Ball size should be 20", 20, GameModel.BALL_SIZE);
        assertEquals("5 brick rows", 5, GameModel.BRICK_ROWS);
        assertEquals("10 brick columns", 10, GameModel.BRICK_COLS);
    }
    
    @Test
    public void testBricksArrayInitialization() {
        boolean[][] bricks = game.getBricks();
        
        assertNotNull("Bricks array should not be null", bricks);
        assertEquals("Should have 5 rows", 5, bricks.length);
        assertEquals("Should have 10 columns", 10, bricks[0].length);
        
        // All bricks should be true initially
        for (int i = 0; i < bricks.length; i++) {
            for (int j = 0; j < bricks[0].length; j++) {
                assertTrue("All bricks should be active initially", bricks[i][j]);
            }
        }
    }
}