// GameControllerTest.java
// Test for GameController

public class GameControllerTest {
    
    public void testControllerCreation() {
        System.out.println("=== Testing Controller Creation ===");
        
        GameModel model = new GameModel();
        GameView view = new GameView(model);
        GameController controller = new GameController(model, view);
        
        System.out.println("✅ Controller created successfully");
        System.out.println("Model attached: " + (model != null));
        System.out.println("View attached: " + (view != null));
    }
    
    public void testGameLoopStart() {
        System.out.println("\n=== Testing Game Loop ===");
        
        GameModel model = new GameModel();
        GameView view = new GameView(model);
        GameController controller = new GameController(model, view);
        
        controller.startGameLoop();
        System.out.println("✅ Game loop started");
        System.out.println("Note: In BlueJ, AnimationTimer runs in background");
        
        // Stop after showing it works
        controller.stop();
        System.out.println("✅ Game loop stopped");
    }
    
    public void testReturnToMenuCallback() {
        System.out.println("\n=== Testing Menu Callback ===");
        
        GameModel model = new GameModel();
        GameView view = new GameView(model);
        GameController controller = new GameController(model, view);
        
        // Create a simple callback
        boolean[] callbackCalled = {false};
        controller.setOnReturnToMenu(() -> {
            callbackCalled[0] = true;
            System.out.println("   Menu callback executed");
        });
        
        System.out.println("✅ Callback set successfully");
        // Note: Can't easily trigger in test, but structure is valid
    }
    
    public static void main(String[] args) {
        GameControllerTest tester = new GameControllerTest();
        
        System.out.println("🎮 GAME CONTROLLER TESTS\n");
        
        tester.testControllerCreation();
        System.out.println("-".repeat(40));
        
        tester.testGameLoopStart();
        System.out.println("-".repeat(40));
        
        tester.testReturnToMenuCallback();
        System.out.println("-".repeat(40));
        
        System.out.println("\n✅ Controller tests completed!");
    }
}