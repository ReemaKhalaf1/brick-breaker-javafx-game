import java.util.ArrayList;
import java.util.List;

public class GameModel {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int PADDLE_WIDTH = 120;
    public static final int PADDLE_HEIGHT = 20;
    public static final int BALL_SIZE = 20;
    public static final int BRICK_ROWS = 5;
    public static final int BRICK_COLS = 10;
    public static final int BRICK_WIDTH = 70;
    public static final int BRICK_HEIGHT = 30;
    
    private double paddleX;
    private double ballX, ballY;
    private double ballSpeedX = 8;
    private double ballSpeedY = -8;
    private int score = 0;
    private int lives = 3;
    private int level = 1;
    private boolean gameRunning = false;
    private boolean gamePaused = false;
    private boolean[][] bricks;
    
    private int currentTheme = 0;
    
    private List<ModelListener> listeners = new ArrayList<>();
    
    public interface ModelListener {
        void onGameStateChanged();
        void onGameOver();
        void onScoreChanged(int score);
        void onLivesChanged(int lives);
        void onLevelChanged(int level);
        void onThemeChanged(int theme);
        void onMessage(String message, String color);
    }
    
    public GameModel() {
        bricks = new boolean[BRICK_ROWS][BRICK_COLS];
        resetBricks();
        resetPositions();
    }
    
    public void startGame() {
        gameRunning = true;
        gamePaused = false;
        score = 0;
        lives = 3;
        level = 1;
        ballSpeedX = 8;
        ballSpeedY = -8;
        resetBricks();
        resetPositions();
        notifyAllListeners();
        notifyMessage("🎮 GAME STARTED!", "#06D6A0");
    }
    
    public void movePaddle(int dx) {
        if (!gameRunning || gamePaused) return;
        
        double newX = paddleX + dx * 2.5;
        if (newX >= 0 && newX <= WIDTH - PADDLE_WIDTH) {
            paddleX = newX;
            notifyGameStateChanged();
        }
    }
    
    public void update() {
        if (!gameRunning || gamePaused) return;
        
        ballX += ballSpeedX;
        ballY += ballSpeedY;
        
        if (ballX <= 0 || ballX >= WIDTH - BALL_SIZE) {
            ballSpeedX = -ballSpeedX;
        }
        if (ballY <= 0) {
            ballSpeedY = -ballSpeedY;
        }
        
        double paddleY = HEIGHT - PADDLE_HEIGHT - 30;
        
        if (ballY + BALL_SIZE >= paddleY && 
            ballY <= paddleY + PADDLE_HEIGHT &&
            ballX + BALL_SIZE >= paddleX && 
            ballX <= paddleX + PADDLE_WIDTH) {
            
            ballSpeedY = -Math.abs(ballSpeedY);
            ballY = paddleY - BALL_SIZE;
            
            score += 5;
            notifyScoreChanged();
        }
        
        boolean brickHit = false;
        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLS; j++) {
                if (bricks[i][j]) {
                    double brickX = j * BRICK_WIDTH + 5;
                    double brickY = i * BRICK_HEIGHT + 50;
                    double brickW = BRICK_WIDTH - 10;
                    double brickH = BRICK_HEIGHT - 5;
                    
                    if (this.ballX + BALL_SIZE >= brickX && 
                        this.ballX <= brickX + brickW &&
                        this.ballY + BALL_SIZE >= brickY && 
                        this.ballY <= brickY + brickH) {
                        
                        bricks[i][j] = false;
                        ballSpeedY = -ballSpeedY;
                        score += 10;
                        brickHit = true;
                        break;
                    }
                }
            }
            if (brickHit) break;
        }
        
        if (brickHit) {
            notifyScoreChanged();
        }
        
        if (ballY >= HEIGHT) {
            lives--;
            notifyLivesChanged();
            
            if (lives <= 0) {
                gameRunning = false;
                notifyGameOver();
                notifyMessage("💀 GAME OVER! Score: " + score, "#EF476F");
            } else {
                resetBall();
                notifyMessage("Life lost! " + lives + " left", "#EF476F");
            }
        }
        
        if (checkLevelComplete()) {
            level++;
            score += 100;
            ballSpeedX *= 1.15;
            ballSpeedY *= 1.15;
            resetBricks();
            resetPositions();
            notifyLevelChanged();
            notifyScoreChanged();
            notifyMessage("🎉 LEVEL COMPLETE! +100", "#4ECDC4");
        }
        
        notifyGameStateChanged();
    }
    
    public void togglePause() {
        gamePaused = !gamePaused;
        notifyMessage(gamePaused ? "⏸️ PAUSED" : "▶️ RESUMED", "#118AB2");
    }
    
    public void changeTheme() {
        currentTheme = (currentTheme + 1) % 4;
        notifyThemeChanged(currentTheme);
        String[] themeNames = {"Classic", "Space", "Ocean", "Forest"};
        notifyMessage("🎨 Theme: " + themeNames[currentTheme], "#FFD166");
    }
    
    public int getCurrentTheme() {
        return currentTheme;
    }
    
    public void prepareForMenu() {
        gameRunning = false;
        gamePaused = false;
    }
    
    public double getPaddleX() { return paddleX; }
    public double getBallX() { return ballX; }
    public double getBallY() { return ballY; }
    public int getScore() { return score; }
    public int getLives() { return lives; }
    public int getLevel() { return level; }
    public boolean isGameRunning() { return gameRunning; }
    public boolean isGamePaused() { return gamePaused; }
    public boolean[][] getBricks() { return bricks; }
    
    private void resetBall() {
        ballX = WIDTH / 2 - BALL_SIZE / 2;
        ballY = HEIGHT / 2 - BALL_SIZE / 2;
        ballSpeedX = (Math.random() > 0.5) ? 8 : -8;
        ballSpeedY = -8;
    }
    
    private void resetBricks() {
        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLS; j++) {
                bricks[i][j] = true;
            }
        }
    }
    
    private void resetPositions() {
        paddleX = WIDTH / 2 - PADDLE_WIDTH / 2;
        resetBall();
    }
    
    private boolean checkLevelComplete() {
        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLS; j++) {
                if (bricks[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }
    
    public void addListener(ModelListener listener) {
        listeners.add(listener);
    }
    
    private void notifyGameStateChanged() {
        for (ModelListener listener : listeners) {
            listener.onGameStateChanged();
        }
    }
    
    private void notifyGameOver() {
        for (ModelListener listener : listeners) {
            listener.onGameOver();
        }
    }
    
    private void notifyScoreChanged() {
        for (ModelListener listener : listeners) {
            listener.onScoreChanged(score);
        }
    }
    
    private void notifyLivesChanged() {
        for (ModelListener listener : listeners) {
            listener.onLivesChanged(lives);
        }
    }
    
    private void notifyLevelChanged() {
        for (ModelListener listener : listeners) {
            listener.onLevelChanged(level);
        }
    }
    
    private void notifyThemeChanged(int theme) {
        for (ModelListener listener : listeners) {
            listener.onThemeChanged(theme);
        }
    }
    
    private void notifyMessage(String message, String color) {
        for (ModelListener listener : listeners) {
            listener.onMessage(message, color);
        }
    }
    
    private void notifyAllListeners() {
        notifyGameStateChanged();
        notifyScoreChanged();
        notifyLivesChanged();
        notifyLevelChanged();
    }
}