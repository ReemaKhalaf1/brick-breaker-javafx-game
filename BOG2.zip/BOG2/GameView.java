import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class GameView implements GameModel.ModelListener {
    private GameModel model;
    private BorderPane gameUI;
    private Canvas canvas;
    private GraphicsContext gc;
    
    private Label scoreLabel;
    private Label livesLabel;
    private Label levelLabel;
    private Label messageLabel;
    
    private Button pauseButton;
    private Button restartButton;
    private Button themeButton;
    private Button menuButton;
    
    public GameView(GameModel model) {
        this.model = model;
        model.addListener(this);
        initializeUI();
    }
    
    private void initializeUI() {
        gameUI = new BorderPane();
        applyTheme();
        
        canvas = new Canvas(GameModel.WIDTH, GameModel.HEIGHT);
        gc = canvas.getGraphicsContext2D();
        
        createTopPanel();
        createCenterPanel();
        createBottomPanel();
        
        drawGame();
    }
    
    public BorderPane getGameUI() {
        return gameUI;
    }
    
    public Canvas getCanvas() {
        return canvas;
    }
    
    public Button getPauseButton() { return pauseButton; }
    public Button getRestartButton() { return restartButton; }
    public Button getThemeButton() { return themeButton; }
    public Button getMenuButton() { return menuButton; }
    
    private void createTopPanel() {
        HBox topPanel = new HBox(20);
        topPanel.setAlignment(javafx.geometry.Pos.CENTER);
        topPanel.setPadding(new javafx.geometry.Insets(15));
        topPanel.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7); -fx-background-radius: 0 0 15 15;");
        
        scoreLabel = createStyledLabel("💰 SCORE: 0", "#06D6A0", 18);
        livesLabel = createStyledLabel("❤️ LIVES: 3", "#EF476F", 18);
        levelLabel = createStyledLabel("🎯 LEVEL: 1", "#4ECDC4", 18);
        messageLabel = createStyledLabel("🎮 PRESS SPACE TO START", "#FFD166", 18);
        
        topPanel.getChildren().addAll(scoreLabel, livesLabel, levelLabel, messageLabel);
        gameUI.setTop(topPanel);
    }
    
    private Label createStyledLabel(String text, String color, int size) {
        Label label = new Label(text);
        label.setFont(Font.font("Arial", FontWeight.BOLD, size));
        label.setTextFill(Color.web(color));
        label.setStyle(
            "-fx-padding: 8 15;" +
            "-fx-background-color: rgba(255, 255, 255, 0.15);" +
            "-fx-background-radius: 10;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 5, 0, 0, 2);"
        );
        return label;
    }
    
    private void createCenterPanel() {
        StackPane centerPanel = new StackPane(canvas);
        centerPanel.setPadding(new javafx.geometry.Insets(20));
        centerPanel.setStyle("-fx-background-color: rgba(0, 0, 0, 0.3); -fx-background-radius: 15;");
        gameUI.setCenter(centerPanel);
    }
    
    private void createBottomPanel() {
        HBox bottomPanel = new HBox(20);
        bottomPanel.setAlignment(javafx.geometry.Pos.CENTER);
        bottomPanel.setPadding(new javafx.geometry.Insets(15));
        bottomPanel.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7); -fx-background-radius: 15 15 0 0;");
        
        pauseButton = createStyledButton("⏸️ PAUSE", "#118AB2");
        restartButton = createStyledButton("🔄 RESTART", "#06D6A0");
        themeButton = createStyledButton("🎨 THEME", "#FFD166");
        menuButton = createStyledButton("🏠 MENU", "#EF476F");
        
        bottomPanel.getChildren().addAll(pauseButton, restartButton, themeButton, menuButton);
        gameUI.setBottom(bottomPanel);
    }
    
    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        button.setTextFill(Color.WHITE);
        button.setStyle(
            "-fx-background-color: " + color + ";" +
            "-fx-background-radius: 12;" +
            "-fx-padding: 12 25;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 6, 0, 0, 2);"
        );
        
        button.setOnMouseEntered(e -> {
            button.setStyle(
                "-fx-background-color: derive(" + color + ", 40%);" +
                "-fx-background-radius: 12;" +
                "-fx-padding: 12 25;" +
                "-fx-cursor: hand;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.6), 8, 0, 0, 3);"
            );
        });
        
        button.setOnMouseExited(e -> {
            button.setStyle(
                "-fx-background-color: " + color + ";" +
                "-fx-background-radius: 12;" +
                "-fx-padding: 12 25;" +
                "-fx-cursor: hand;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 6, 0, 0, 2);"
            );
        });
        
        return button;
    }
    
    private void applyTheme() {
        int theme = model.getCurrentTheme();
        switch (theme) {
            case 1:
                gameUI.setStyle("-fx-background-color: linear-gradient(to bottom, #0a0a2a, #000000);");
                break;
            case 2:
                gameUI.setStyle("-fx-background-color: linear-gradient(to bottom, #0a2463, #1e6091);");
                break;
            case 3:
                gameUI.setStyle("-fx-background-color: linear-gradient(to bottom, #1b4332, #2d6a4f);");
                break;
            default:
                gameUI.setStyle("-fx-background-color: linear-gradient(to bottom, #0f3460, #1a1a2e);");
        }
    }
    
    private Color getBackgroundColor() {
        int theme = model.getCurrentTheme();
        switch (theme) {
            case 1: return Color.web("#0a0a2a");
            case 2: return Color.web("#0a2463");
            case 3: return Color.web("#1b4332");
            default: return Color.web("#0f3460");
        }
    }
    
    public void drawGame() {
        gc.clearRect(0, 0, GameModel.WIDTH, GameModel.HEIGHT);
        
        gc.setFill(getBackgroundColor());
        gc.fillRect(0, 0, GameModel.WIDTH, GameModel.HEIGHT);
        
        if (model.getCurrentTheme() == 1) {
            gc.setFill(Color.WHITE);
            for (int i = 0; i < 50; i++) {
                double x = Math.random() * GameModel.WIDTH;
                double y = Math.random() * GameModel.HEIGHT;
                double size = Math.random() * 2 + 1;
                gc.fillOval(x, y, size, size);
            }
        }
        
        boolean[][] bricks = model.getBricks();
        for (int i = 0; i < GameModel.BRICK_ROWS; i++) {
            for (int j = 0; j < GameModel.BRICK_COLS; j++) {
                if (bricks[i][j]) {
                    double brickX = j * GameModel.BRICK_WIDTH + 5;
                    double brickY = i * GameModel.BRICK_HEIGHT + 50;
                    
                    Color brickColor;
                    switch (i) {
                        case 0: brickColor = Color.web("#FF6B6B"); break;
                        case 1: brickColor = Color.web("#FFD166"); break;
                        case 2: brickColor = Color.web("#06D6A0"); break;
                        case 3: brickColor = Color.web("#118AB2"); break;
                        default: brickColor = Color.web("#4ECDC4"); break;
                    }
                    
                    gc.setFill(brickColor);
                    gc.fillRect(
                        brickX,
                        brickY,
                        GameModel.BRICK_WIDTH - 10,
                        GameModel.BRICK_HEIGHT - 5
                    );
                    
                    gc.setStroke(Color.web("#FFFFFF", 0.3));
                    gc.setLineWidth(1);
                    gc.strokeRect(
                        brickX,
                        brickY,
                        GameModel.BRICK_WIDTH - 10,
                        GameModel.BRICK_HEIGHT - 5
                    );
                }
            }
        }
        
        gc.setFill(Color.web("#06D6A0"));
        gc.fillRoundRect(
            model.getPaddleX(), 
            GameModel.HEIGHT - GameModel.PADDLE_HEIGHT - 30,
            GameModel.PADDLE_WIDTH, 
            GameModel.PADDLE_HEIGHT, 
            15, 15
        );
        
        gc.setStroke(Color.web("#FFFFFF", 0.5));
        gc.setLineWidth(2);
        gc.strokeRoundRect(
            model.getPaddleX(), 
            GameModel.HEIGHT - GameModel.PADDLE_HEIGHT - 30,
            GameModel.PADDLE_WIDTH, 
            GameModel.PADDLE_HEIGHT, 
            15, 15
        );
        
        gc.setFill(Color.web("#FF6B6B"));
        gc.fillOval(
            model.getBallX(), 
            model.getBallY(), 
            GameModel.BALL_SIZE, 
            GameModel.BALL_SIZE
        );
        
        gc.setFill(Color.web("#FFFFFF", 0.7));
        gc.fillOval(
            model.getBallX() + 4, 
            model.getBallY() + 4, 
            GameModel.BALL_SIZE - 8, 
            GameModel.BALL_SIZE - 8
        );
    }
    
    public void showGameOver() {
        gc.setFill(Color.web("rgba(0, 0, 0, 0.85)"));
        gc.fillRect(0, 0, GameModel.WIDTH, GameModel.HEIGHT);
        
        gc.setFill(Color.web("#EF476F"));
        gc.setFont(Font.font("Arial Black", 48));
        gc.fillText("GAME OVER", GameModel.WIDTH/2 - 150, GameModel.HEIGHT/2 - 100);
        
        gc.setFill(Color.web("#FFD166"));
        gc.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        gc.fillText("FINAL SCORE: " + model.getScore(), 
                   GameModel.WIDTH/2 - 120, GameModel.HEIGHT/2 - 30);
        
        gc.setFont(Font.font("Arial", 22));
        gc.fillText("Press SPACE to restart", 
                   GameModel.WIDTH/2 - 140, GameModel.HEIGHT/2 + 60);
        gc.fillText("Press M for Main Menu", 
                   GameModel.WIDTH/2 - 140, GameModel.HEIGHT/2 + 100);
    }
    
    @Override
    public void onGameStateChanged() {
        drawGame();
    }
    
    @Override
    public void onGameOver() {
        showGameOver();
        messageLabel.setText("💀 GAME OVER");
        messageLabel.setTextFill(Color.web("#EF476F"));
    }
    
    @Override
    public void onScoreChanged(int score) {
        scoreLabel.setText("💰 SCORE: " + score);
    }
    
    @Override
    public void onLivesChanged(int lives) {
        livesLabel.setText("❤️ LIVES: " + lives);
    }
    
    @Override
    public void onLevelChanged(int level) {
        levelLabel.setText("🎯 LEVEL: " + level);
    }
    
    @Override
    public void onThemeChanged(int theme) {
        applyTheme();
        drawGame();
    }
    
    @Override
    public void onMessage(String message, String color) {
        messageLabel.setText(message);
        messageLabel.setTextFill(Color.web(color));
    }
}