import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class MainMenu extends Application {

    private Stage primaryStage;
    private StackPane root;
    private Scene menuScene;
    private int highScore = 0;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.root = new StackPane();

        showMainMenu();

        menuScene = new Scene(root, 800, 600);

        primaryStage.setTitle("🎮 Brick Breaker Ultimate");
        primaryStage.setScene(menuScene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    private void showMainMenu() {
        root.getChildren().clear();

        VBox menu = new VBox(30);
        menu.setAlignment(Pos.CENTER);
        menu.setPadding(new Insets(40));
        menu.setStyle("-fx-background-color: linear-gradient(to bottom, #0f3460, #1a1a2e);");

        Label title = new Label("🎮 BRICK BREAKER ULTIMATE");
        title.setFont(Font.font("Arial Black", 48));
        title.setTextFill(Color.web("#FFD166"));

        Label icon = new Label("🏓");
        icon.setFont(Font.font("Arial", 120));
        icon.setTextFill(Color.web("#4ECDC4"));

        Button playBtn = createMenuButton("▶️ START GAME", "#06D6A0");
        playBtn.setOnAction(e -> startGame());

        Button howBtn = createMenuButton("📖 HOW TO PLAY", "#4ECDC4");
        howBtn.setOnAction(e -> showHowToPlay());

        Button scoreBtn = createMenuButton("🏆 HIGH SCORE: " + highScore, "#FFD166");
        scoreBtn.setOnAction(e -> showHighScores());

        Button exitBtn = createMenuButton("🚪 EXIT", "#EF476F");
        exitBtn.setOnAction(e -> Platform.exit());

        VBox btnBox = new VBox(15, playBtn, howBtn, scoreBtn, exitBtn);
        btnBox.setAlignment(Pos.CENTER);

        menu.getChildren().addAll(title, icon, btnBox);
        root.getChildren().add(menu);
    }

    private Button createMenuButton(String text, String color) {
        Button btn = new Button(text);
        btn.setFont(Font.font("Arial", FontWeight.BOLD, 22));
        btn.setTextFill(Color.WHITE);
        btn.setPrefSize(400, 60);
        btn.setFocusTraversable(false);

        btn.setStyle(
            "-fx-background-color: " + color + ";" +
            "-fx-background-radius: 30;" +
            "-fx-border-color: white;" +
            "-fx-border-radius: 30;" +
            "-fx-border-width: 2;"
        );

        return btn;
    }

    private void startGame() {
        GameModel model = new GameModel();
        GameView view = new GameView(model);
        GameController controller = new GameController(model, view);

        controller.setOnReturnToMenu(() -> {
            int finalScore = model.getScore();
            if (finalScore > highScore) highScore = finalScore;
            primaryStage.setScene(menuScene);
            showMainMenu();
        });

        Scene gameScene = new Scene(view.getGameUI(), 800, 700);
        primaryStage.setScene(gameScene);
        controller.startGameLoop();
    }

    private void showHowToPlay() {
        root.getChildren().clear();

        BorderPane container = new BorderPane();
        container.setStyle("-fx-background-color: linear-gradient(to bottom, #0f3460, #1a1a2e);");

        Label title = new Label("📖 HOW TO PLAY");
        title.setFont(Font.font("Arial Black", 36));
        title.setTextFill(Color.web("#FFD166"));
        title.setPadding(new Insets(20));
        container.setTop(title);

        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        
        VBox content = new VBox(10);
        content.setPadding(new Insets(30));
        content.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); -fx-background-radius: 10;");

        content.getChildren().addAll(
            createSectionTitle("🎯 OBJECTIVE", "#4ECDC4"),
            createInstruction("• Break all bricks with the ball"),
            createInstruction("• Don't let the ball fall below the paddle"),
            createInstruction("• Score as many points as possible"),
            
            createSectionTitle("🎮 CONTROLS", "#FFD166"),
            createInstruction("• LEFT ARROW or A → Move paddle left"),
            createInstruction("• RIGHT ARROW or D → Move paddle right"),
            createInstruction("• P → Pause/Resume game"),
            createInstruction("• M or ESC → Return to Main Menu"),
            createInstruction("• SPACE → Start/Restart game"),
            createInstruction("• T → Change theme (4 awesome themes!)"),
            
            createSectionTitle("🏆 SCORING", "#06D6A0"),
            createInstruction("• Breaking a brick → +10 points"),
            createInstruction("• Hitting the paddle → +5 points"),
            createInstruction("• Completing a level → +100 points"),
            
            createSectionTitle("❤️ LIVES", "#EF476F"),
            createInstruction("• You start with 3 lives"),
            createInstruction("• Lose a life when ball falls"),
            createInstruction("• Game ends when no lives remain"),
            
            createSectionTitle("🎨 THEMES", "#9D4EDD"),
            createInstruction("• Press T to cycle through themes"),
            createInstruction("• 🟦 DEFAULT - Classic blue gradient"),
            createInstruction("• 🌌 SPACE - Dark space with stars"),
            createInstruction("• 🌊 OCEAN - Deep ocean blue"),
            createInstruction("• 🌳 FOREST - Green forest theme")
        );

        scroll.setContent(content);
        container.setCenter(scroll);

        Button backBtn = createMenuButton("🔙 BACK TO MENU", "#118AB2");
        backBtn.setPrefSize(300, 50);
        backBtn.setFocusTraversable(false);
        backBtn.setOnAction(e -> showMainMenu());

        HBox bottom = new HBox(backBtn);
        bottom.setAlignment(Pos.CENTER);
        bottom.setPadding(new Insets(20));
        container.setBottom(bottom);

        root.getChildren().add(container);
    }
    
    private Label createSectionTitle(String text, String color) {
        Label label = new Label(text);
        label.setFont(Font.font("Arial Black", 24));
        label.setTextFill(Color.web(color));
        label.setStyle("-fx-padding: 15 0 5 0;");
        return label;
    }
    
    private Label createInstruction(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("Arial", 18));
        label.setTextFill(Color.web("#FFFFFF"));
        label.setWrapText(true);
        label.setStyle("-fx-padding: 5 0 5 20;");
        return label;
    }

    private void showHighScores() {
        root.getChildren().clear();

        BorderPane container = new BorderPane();
        container.setStyle("-fx-background-color: linear-gradient(to bottom, #0f3460, #1a1a2e);");

        Label title = new Label("🏆 HIGH SCORES");
        title.setFont(Font.font("Arial Black", 36));
        title.setTextFill(Color.web("#FFD166"));
        title.setPadding(new Insets(20));
        container.setTop(title);

        VBox centerBox = new VBox(20);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setPadding(new Insets(30));
        centerBox.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); -fx-background-radius: 10;");

        Label scoreLabel = new Label(String.valueOf(highScore));
        scoreLabel.setFont(Font.font("Arial", FontWeight.BOLD, 72));
        scoreLabel.setTextFill(Color.web("#FFD166"));

        Label recentLabel = new Label("RECENT SCORES");
        recentLabel.setFont(Font.font("Arial Black", 22));
        recentLabel.setTextFill(Color.web("#06D6A0"));

        VBox rankingsBox = new VBox(10);
        rankingsBox.setAlignment(Pos.CENTER);

        int[] recentScores = {
            highScore,
            Math.max(0, highScore - 150),
            Math.max(0, highScore - 300),
            Math.max(0, highScore - 500),
            Math.max(0, highScore - 750)
        };

        for (int i = 0; i < recentScores.length; i++) {
            HBox rankRow = new HBox(15);
            rankRow.setAlignment(Pos.CENTER);

            Label rankNumber = new Label((i + 1) + ".");
            rankNumber.setFont(Font.font("Arial", FontWeight.BOLD, 20));
            rankNumber.setTextFill(Color.web("#FFFFFF"));

            Label score = new Label(String.valueOf(recentScores[i]));
            score.setFont(Font.font("Arial", 18));
            score.setTextFill(Color.web(i == 0 ? "#FFD166" : "#E0E0E0"));

            rankRow.getChildren().addAll(rankNumber, score);
            rankingsBox.getChildren().add(rankRow);
        }

        centerBox.getChildren().addAll(
            scoreLabel,
            new Label(""),
            recentLabel,
            rankingsBox
        );

        container.setCenter(centerBox);

        Button backBtn = createMenuButton("🔙 BACK TO MENU", "#118AB2");
        backBtn.setPrefSize(300, 50);
        backBtn.setFocusTraversable(false);
        backBtn.setOnAction(e -> showMainMenu());

        HBox bottom = new HBox(backBtn);
        bottom.setAlignment(Pos.CENTER);
        bottom.setPadding(new Insets(20));
        container.setBottom(bottom);

        root.getChildren().add(container);
    }

    public static void main(String[] args) {
        launch(args);
    }
}