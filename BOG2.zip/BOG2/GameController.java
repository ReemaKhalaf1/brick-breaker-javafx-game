import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyCode;

public class GameController {
    private GameModel model;
    private GameView view;
    private AnimationTimer gameLoop;
    private Runnable onReturnToMenu;
    private boolean isRunning = false;
    
    public GameController(GameModel model, GameView view) {
        this.model = model;
        this.view = view;
        setupControls();
    }
    
    public void setOnReturnToMenu(Runnable handler) {
        this.onReturnToMenu = handler;
    }
    
    private void setupControls() {
        view.getCanvas().setFocusTraversable(true);
        
        view.getCanvas().setOnKeyPressed(e -> {
            KeyCode code = e.getCode();
            
            if (code == KeyCode.LEFT || code == KeyCode.A) {
                model.movePaddle(-25);
            }
            else if (code == KeyCode.RIGHT || code == KeyCode.D) {
                model.movePaddle(25);
            }
            else if (code == KeyCode.SPACE) {
                if (!model.isGameRunning()) {
                    model.startGame();
                }
            }
            else if (code == KeyCode.P) {
                model.togglePause();
            }
            else if (code == KeyCode.T) {
                model.changeTheme();
            }
            else if (code == KeyCode.M || code == KeyCode.ESCAPE) {
                returnToMainMenuImmediately();
            }
        });
        
        view.getPauseButton().setOnAction(e -> {
            model.togglePause();
            view.getCanvas().requestFocus();
        });
        
        view.getRestartButton().setOnAction(e -> {
            model.startGame();
            view.getCanvas().requestFocus();
        });
        
        view.getThemeButton().setOnAction(e -> {
            model.changeTheme();
            view.getCanvas().requestFocus();
        });
        
        view.getMenuButton().setOnAction(e -> {
            returnToMainMenuImmediately();
        });
        
        view.getCanvas().setOnMouseClicked(e -> view.getCanvas().requestFocus());
    }
    
    public void startGameLoop() {
        if (isRunning) {
            return;
        }
        
        isRunning = true;
        gameLoop = new AnimationTimer() {
            private long lastUpdate = 0;
            
            @Override
            public void handle(long now) {
                if (lastUpdate == 0) {
                    lastUpdate = now;
                }
                
                long nanosPerFrame = 16_666_666;
                if (now - lastUpdate >= nanosPerFrame) {
                    if (model.isGameRunning() && !model.isGamePaused()) {
                        model.update();
                    }
                    lastUpdate = now;
                }
            }
        };
        
        gameLoop.start();
        view.getCanvas().requestFocus();
    }
    
    private void returnToMainMenuImmediately() {
        isRunning = false;
        
        if (gameLoop != null) {
            gameLoop.stop();
            gameLoop = null;
        }
        
        model.prepareForMenu();
        
        if (onReturnToMenu != null) {
            onReturnToMenu.run();
        }
    }
    
    public void stop() {
        isRunning = false;
        if (gameLoop != null) {
            gameLoop.stop();
            gameLoop = null;
        }
        model.prepareForMenu();
    }
}